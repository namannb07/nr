#!/bin/bash

options=("Option 1" "Option 2" "Option 3" "Quit")

PS3="Select an option (enter number): "
select opt in "${options[@]}"
do
    case $REPLY in
        1) echo "You chose Option 1" ;;
        2) echo "You chose Option 2" ;;
        3) echo "You chose Option 3" ;;
        4) echo "Exiting..." ; break ;;
        *) echo "Invalid option. Please choose a number between 1 and 4." ;;
    esac
done
