#!/bin/bash

read -p "Enter the first number: " a
read -p "Enter the second number: " b

echo "Select an arithmetic operation:"
echo "1. Addition"
echo "2. Subtraction"
echo "3. Multiplication"
echo "4. Division"
echo "5. Modulus"

read -p "Enter your choice (1-5): " operation

case $operation in
    1)
        result=$((a + b))
        echo "Result: $a + $b = $result"
        ;;
    2)
        result=$((a - b))
        echo "Result: $a - $b = $result"
        ;;
    3)
        result=$((a * b))
        echo "Result: $a * $b = $result"
        ;;
    4)
        if [ $b -ne 0 ]; then
            result=$((a / b))
            echo "Result: $a / $b = $result"
        else
            echo "Error: Division by zero is not allowed."
        fi
        ;;
    5)
        if [ $b -ne 0 ]; then
            result=$((a % b))
            echo "Result: $a % $b = $result"
        else
            echo "Error: Division by zero is not allowed."
        fi
        ;;
    *)
        echo "Invalid operation"
        ;;
esac
