#!/bin/bash

echo "(1)"
for (( i=1; i<=5; i++ ))
do
    for (( j=1; j<=i; j++ ))
    do
        echo -n "$j "
    done
    echo
done

echo

echo "(2)"
for (( i=1; i<=5; i++ ))
do
    for (( space=5; space>i; space-- ))
    do
        echo -n " "
    done
    for (( j=1; j<=i; j++ ))
    do
        if [ $i -eq 2 ] || [ $i -eq 4 ]; then
            echo -n "# "
        else
            echo -n "* "
        fi
    done
    echo
done
