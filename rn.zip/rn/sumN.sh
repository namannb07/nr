#!/bin/bash

read -p "Enter a positive integer N: " N

sum=0
counter=1

until [ $counter -gt $N ]
do
    sum=$((sum + counter))
    counter=$((counter + 1))
done

echo "The sum of the first $N natural numbers is: $sum"
