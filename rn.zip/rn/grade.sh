#!/bin/bash

read -p "Enter the score (0-100): " score

if [ $score -ge 90 ] && [ $score -le 100 ]; then
    grade="A"
elif [ $score -ge 80 ]; then
    grade="B"
elif [ $score -ge 70 ]; then
    grade="C"
elif [ $score -ge 60 ]; then
    grade="D"
elif [ $score -ge 50 ]; then
    grade="E"
else
    grade="F"
fi

echo "The grade is: $grade"
